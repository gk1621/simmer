Database = {
        'host': 'localhost',
        'user': 'zedrunner',
        'password': '#ZedRunner@2021',
        'database': 'zed'
}
BOT = {
        'token': '1793290514:AAFjFd95hzTxOb-lxN1ymc3vV7uBcUlJ-Xc' ,
        'channel': '@zed_channel_test'
}

API_RETRY_COUNT = 3
